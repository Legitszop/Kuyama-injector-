<?php
set_time_limit(-1);
// max_execution_time(-1

$base = 'bazowe/base.txt';

$output = 'wynikowe/result.txt';
$result = [];

foreach(file($base) as $item) {
    $url = 'https://instafaster.com/api/v2key=' . trim($item) . '&action=balance';
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, 1);
    $exec = curl_exec($ch);
    if($exec != '{"error":"Invalid API key"}') {
        echo $exec . "\n";
        $fp = fopen($output, 'a');//opens file in append mode  
        fwrite($fp, "\n" . trim($item) . ': ' . $exec);  
        fclose($fp);  
    }

    // echo $item;
    curl_close($ch);
}

// var_dump($result);